package mailer.crypt;

public enum DataTypeEnum {
    REPLY, FORWARD
}
